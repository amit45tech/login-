<!DOCTYPE html>
<html>
<head>
	<title>Homepage</title>
</head>
<body style="background-image: url(images/local.jpg);">

	
	<center style="margin-top: 300px;"><h1>Welcome to Home Page</h1>
	<a href="logout.php"><button>Log Out</button></a></center>

</body>
</html>