1. go to phpmyadmin page on browser
2. create a database with name 'ca2'
3. import the "ca2.sql" file in that database
4. copy the folder in the xamp/htdoc 

